const Hello = () => {
  return <h1>Hello, Solidjs</h1>
}
export default Hello
