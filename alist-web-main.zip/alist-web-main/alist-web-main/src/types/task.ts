export interface TaskInfo {
  id: string
  name: string
  state: string
  status: string
  progress: number
  error: string
}
